#!/bin/sh

ln -s /sbin/nasutil /sbin/mem_stress
mem_stress