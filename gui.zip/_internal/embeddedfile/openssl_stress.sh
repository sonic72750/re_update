#!/bin/sh

MAX_CPU_STRESS_COUNT=$(grep -c ^processor /proc/cpuinfo)

while true; do
  CPUSTRESSCOUNT=$(ps | grep -v grep | grep "openssl speed sha512" | wc -l)
  while [ "$CPUSTRESSCOUNT" -lt "$MAX_CPU_STRESS_COUNT" ]; do
    openssl speed sha512 > /dev/null 2>&1 &
    CPUSTRESSCOUNT=$(ps | grep -v grep | grep "openssl speed sha512" | wc -l)
  done
  sleep 1
done
