#!/bin/sh

j=$(grep -c ^processor /proc/cpuinfo)

for((i=0 ; i<j ; i++));do
	echo `taskset  -c $i  yes > /dev/null & `
done

taskset  -c 1 yes > /dev/null